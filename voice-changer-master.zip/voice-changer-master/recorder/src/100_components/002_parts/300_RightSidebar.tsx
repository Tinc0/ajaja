import React from "react";
export const RightSidebar = () => {

    return (
        <>
            <div className="right-sidebar">
                No info.
            </div>
        </>
    );
};

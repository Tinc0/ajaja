import torch

hubert = torch.hub.load("bshall/hubert:main", "hubert_soft")

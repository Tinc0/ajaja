module.exports = {
    plugins: {
        autoprefixer: {},
        "postcss-nested": {},
    },
};

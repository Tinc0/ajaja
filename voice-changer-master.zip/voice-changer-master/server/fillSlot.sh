for i in {1..199}; do
    cp -r model_dir/0 model_dir/$i
done
